const dbConfig = {
    apiKey: "",
    authDomain: "twindb-41378.firebaseapp.com",
    databaseURL: "https://twindb-41378-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "twindb-41378",
    storageBucket: "twindb-41378.appspot.com",
};

module.exports = dbConfig;